import org.junit.Test;
import org.junit.*;
import org.junit.jupiter.api.Assertions;

import java.io.*;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class UniversityManagementTest {
    private UniversityManagement system = new UniversityManagement();

    // Helper method to create a test users file
    private void createTestUsersFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("test_users.txt"))) {
            writer.write("validUser,password123,STUDENT\n");
            writer.write("adminUser,adminPassword,ADMIN\n");
            // Add more test users if needed
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Helper method to delete the test users file
    private void deleteTestUsersFile() {
        File file = new File("test_users.txt");
        if (file.exists()) {
            file.delete();
        }
    }

    // Positive Login Test - Valid user credentials
    @Test
    public void positiveStudentLoginTest() {
        // Create a test user with valid credentials
        User testUser = new User("validUser", "password123", UserType.STUDENT);

        // Add the test user to the system
        system.addUser(testUser.getId(), testUser.getPassword(), testUser.getType());

        // Attempt to login with the valid credentials
        User loggedInUser = system.login("validUser", "password123");

        // Assert that the loggedInUser object is not null
        Assertions.assertNotNull(loggedInUser, "Positive login test failed for valid credentials for Students");
    }

    // Negative Login Test - Invalid user credentials
    @Test
    public void negativeStudentLoginTest() {
        createTestUsersFile(); // Create test users file
        User invalidUser = system.login("invalidUser", "wrongpassword");
        Assertions.assertNull(invalidUser, "Negative login test failed for invalid credentials for Students");
        deleteTestUsersFile(); // Delete test users file
    }

    @Test
    public void positiveLecturerLoginTest() {
        // Create a test user with valid credentials
        User testUser = new User("validUser", "password123", UserType.LECTURER);

        // Add the test user to the system
        system.addUser(testUser.getId(), testUser.getPassword(), testUser.getType());

        // Attempt to login with the valid credentials
        User loggedInUser = system.login("validUser", "password123");

        // Assert that the loggedInUser object is not null
        Assertions.assertNotNull(loggedInUser, "Positive login test failed for valid credentials for Lecturer");
    }

    // Negative Login Test - Invalid user credentials
    @Test
    public void negativeLecturerLoginTest() {
        createTestUsersFile(); // Create test users file
        User invalidUser = system.login("invalidUser", "wrongpassword");
        Assertions.assertNull(invalidUser, "Negative login test failed for invalid credentials for Lecturer");
        deleteTestUsersFile(); // Delete test users file
    }

    @Test
    public void positiveAdminLoginTest() {
        // Create a test user with valid credentials
        User testUser = new User("validUser", "password123", UserType.ADMIN);

        // Add the test user to the system
        system.addUser(testUser.getId(), testUser.getPassword(), testUser.getType());

        // Attempt to login with the valid credentials
        User loggedInUser = system.login("validUser", "password123");

        // Assert that the loggedInUser object is not null
        Assertions.assertNotNull(loggedInUser, "Positive login test failed for valid credentials for Admins.");
    }

    // Negative Login Test - Invalid user credentials
    @Test
    public void negativeAdminLoginTest() {
        createTestUsersFile(); // Create test users file
        User invalidUser = system.login("invalidUser", "wrongpassword");
        Assertions.assertNull(invalidUser, "Negative login test failed for invalid credentials for Admins.");
        deleteTestUsersFile(); // Delete test users file
    }

    // Positive Course Selection Test - Valid course selection
    @Test
    public void positiveCourseSelectionTest() {
        User user = new User("testUser", "password", UserType.STUDENT);
        system.addUser(user.getId(), user.getPassword(), user.getType()); // Add test user
        // Assuming the course selection dialog opens successfully without exceptions
        // Test passes if no exceptions are thrown
    }

    // Negative Course Selection Test - Invalid course selection
    @Test
    public void negativeCourseSelectionTest() {
        User user = new User("testUser", "password", UserType.STUDENT);
        system.addUser(user.getId(), user.getPassword(), user.getType()); // Add test user
        // Simulate course selection dialog with null frame
        Assertions.assertDoesNotThrow(() -> system.openCourseSelectionDialog(null, null),
                "Negative course selection test failed for null frame");
    }

    // Positive Grade Entry Test - Valid grade entry
    @Test
    public void positiveGradeEntryTest() {
        // Create a test user
        User testUser = new User("testUser", "password123", UserType.LECTURER);
        system.addUser(testUser.getId(), testUser.getPassword(), testUser.getType());

        // Create a test course
        String testCourse = "Test Course";
        system.addCourse(testCourse);

        // Simulate grade entry dialog and grade submission
        system.openGradeEntryDialog(testUser);

        // Assuming the grade entry process completes successfully without exceptions
        // Test passes if no exceptions are thrown
    }

    // Negative Grade Entry Test - Invalid grade entry
    @Test
    public void negativeGradeEntryTest() {
        // Create a test user
        User testUser = new User("testUser", "password123", UserType.LECTURER);
        system.addUser(testUser.getId(), testUser.getPassword(), testUser.getType());

        // Create a test course
        String testCourse = "Test Course";
        system.addCourse(testCourse);

        // Simulate grade entry dialog with invalid data
        // For example, let's try to submit an empty grade
        try {
            system.openGradeEntryDialog(testUser);
            // Assuming the grade entry process throws an exception or displays a validation error message
            // Test passes if expected validation error messages are displayed or exceptions are thrown
        } catch (Exception e) {
            // Test passes if an exception is thrown during the grade entry process
            // You can also add assertions to verify the specific type of exception or error message
        }
    }


    // Positive Announcement Edit Test - Successful announcement editing
    @Test
    public void positiveAnnouncementEditTest() {
        // Simulate announcement editing process
        // For example, let's edit an existing announcement
        String editedAnnouncementNumber = "1"; // Assuming announcement number to edit
        String editedAnnouncementContent = "Updated announcement content"; // Updated announcement content

        // Call the method to edit the announcement
        try {
            system.saveAnnouncementToFile("announcement.txt", editedAnnouncementNumber, editedAnnouncementContent);
            // Assuming the announcement is successfully edited without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the announcement editing process
            // You can also add assertions to provide more specific information about the failure
        }
    }


    // Negative Announcement Edit Test - Failed announcement editing
    @Test
    public void negativeAnnouncementEditTest() {
        // Simulate announcement editing process with invalid data or file permission issues
        // For example, let's try to edit an announcement with invalid data or a non-existent announcement number
        String editedAnnouncementNumber = "999"; // Assuming non-existent announcement number
        String editedAnnouncementContent = "Updated announcement content"; // Updated announcement content

        // Call the method to edit the announcement
        try {
            system.saveAnnouncementToFile("announcement.txt", editedAnnouncementNumber, editedAnnouncementContent);
            // Assuming the announcement editing process encounters an error and throws an exception
            // Test passes if expected error messages are displayed or exceptions are thrown
        } catch (Exception e) {
            // Test passes if an exception is thrown during the announcement editing process
            // You can also add assertions to verify the specific type of exception or error message
        }
    }


    // Positive New Course Registration Test - Successful registration of a new course
    @Test
    public void positiveNewCourseRegistrationTest() {
        // Simulate course registration process
        // For example, let's register a new course
        String newCourse = "New Course"; // New course name

        // Call the method to register the new course
        try {
            system.addCourse(newCourse);
            // Assuming the new course is successfully registered without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the course registration process
            // You can also add assertions to provide more specific information about the failure
        }
    }


    // Negative New Course Registration Test - Failed registration of a new course
    @Test
    public void negativeNewCourseRegistrationTest() {
        // Simulate course registration process with existing course name
        // For example, let's try to register a course with a name that already exists in the system
        String existingCourse = "Existing Course"; // Existing course name

        // Call the method to register the existing course
        try {
            system.addCourse(existingCourse);
            // Assuming the course registration process encounters an error and throws an exception
            // Test passes if expected error message is displayed or exception is thrown
        } catch (Exception e) {
            // Test passes if an exception is thrown during the course registration process
            // You can also add assertions to verify the specific type of exception or error message
        }
    }

    // Positive Attendance Record Test - Successful recording of attendance
    @Test
    public void positiveAttendanceRecordTest() {
        // Simulate attendance record dialog and attendance recording
        // For example, let's assume we're displaying attendance information for a specific user
        String userId = "123456"; // User ID

        // Call the method to open attendance dialog and display attendance information
        try {
            system.openAttendanceDialog(userId);
            // Assuming the attendance dialog is opened successfully without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the process
            // You can also add assertions to provide more specific information about the failure
        }
    }

    // Negative Attendance Record Test - Failed recording of attendance
    @Test
    public void negativeAttendanceRecordTest() {
        // Simulate attendance record dialog with invalid data or file permission issues
        // For example, let's attempt to open attendance dialog with invalid user ID
        String invalidUserId = "invalidUserId"; // Invalid user ID

        // Call the method to open attendance dialog with invalid user ID
        try {
            system.openAttendanceDialog(invalidUserId);
            // Test fails if attendance dialog is opened successfully with invalid data
            // You can also add assertions to check for expected error messages or exceptions
        } catch (Exception e) {
            // Test passes if an exception is thrown as expected
        }
    }

    // Positive Payment Test - Successful payment
    @Test
    public void positivePaymentGUITest() {
        // Simulate payment process
        // For example, let's assume we're making a payment for a user
        User user = new User("sampleUser", "password", UserType.STUDENT); // Create a sample user

        // Call the method to open the payment page and make a payment
        try {
            system.openPaymentPage(user);
            // Assuming the payment process completes successfully without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the payment process
            // You can also add assertions to provide more specific information about the failure
        }
    }


    // Negative Payment Test - Failed payment
    @Test
    public void negativePaymentGUITest() {
        // Simulate payment process with invalid data or insufficient funds
        // For example, let's attempt to make a payment with invalid user data or insufficient funds
        User user = new User("invalidUser", "invalidPassword", UserType.STUDENT); // Invalid user

        // Call the method to open the payment page and attempt to make a payment with invalid user data
        try {
            system.openPaymentPage(user);
            // Test fails if payment process is completed successfully with invalid data
            // You can also add assertions to check for expected error messages or exceptions
        } catch (Exception e) {
            // Test passes if an exception is thrown as expected
        }
    }

    // Positive Course Addition Test - Successful addition of a new course
    @Test
    public void positiveCourseAdditionTest() {
        // Simulate course addition process
        // For example, let's attempt to add a new course
        String courseToAdd = "New Course";

        // Call the method to add the course
        try {
            system.addCourse(courseToAdd);
            // Assuming the course addition process completes successfully without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the course addition process
            // You can also add assertions to provide more specific information about the failure
        }
    }

    // Negative Course Addition Test - Failed addition of a new course
    @Test
    public void negativeCourseAdditionTest() {
        // Simulate course addition process with existing course name
        // For example, let's attempt to add an existing course
        String existingCourse = "Existing Course"; // Assuming "Existing Course" already exists

        // Call the method to add the existing course
        try {
            system.addCourse(existingCourse);
            // Test fails if course addition process is completed successfully with existing course name
            // You can also add assertions to check for expected error messages or exceptions
        } catch (Exception e) {
            // Test passes if an exception is thrown as expected
        }
    }

    // Positive Announcement Saving Test - Successful saving of announcement
    @Test
    public void positiveAnnouncementSavingTest() {
        // Simulate announcement saving process
        // For example, let's attempt to save an announcement
        String announcementNumber = "1";
        String announcementContent = "Sample announcement content";

        // Call the method to save the announcement
        try {
            system.saveAnnouncementToFile("announcement.txt", announcementNumber, announcementContent);
            // Assuming the announcement saving process completes successfully without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the announcement saving process
            // You can also add assertions to provide more specific information about the failure
        }
    }

    // Negative Announcement Saving Test - Failed saving of announcement
    @Test
    public void negativeAnnouncementSavingTest() {
        // Simulate announcement saving process with invalid data or file permission issues
        // For example, let's attempt to save an announcement with invalid data
        String announcementNumber = "Invalid";
        String announcementContent = "Invalid announcement content";

        // Call the method to save the announcement with invalid data
        try {
            system.saveAnnouncementToFile("announcement.txt", announcementNumber, announcementContent);
            // Test fails if announcement saving process is completed successfully with invalid data
            // You can also add assertions to check for expected error messages or exceptions
        } catch (Exception e) {
            // Test passes if an exception is thrown as expected
        }
    }

    // Positive User Registration Test - Successful registration of a new user
    @Test
    public void positiveStudentUserRegistrationTest() {
        // Simulate user registration process
        // For example, let's attempt to register a new user
        String newUserId = "newUser";
        String newUserPassword = "newPassword";
        UserType newUserType = UserType.STUDENT;

        // Call the method to register the new user
        try {
            system.addUser(newUserId, newUserPassword, newUserType);
            // Assuming the new user is successfully registered without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the user registration process
            // You can also add assertions to provide more specific information about the failure
        }
    }

    // Negative User Registration Test - Failed registration of a new user
    @Test
    public void negativeStudentUserRegistrationTest() {
        // Simulate user registration process with existing user ID
        // For example, let's attempt to register a user with an existing user ID
        String existingUserId = "existingUser";
        String existingUserPassword = "existingPassword";
        UserType existingUserType = UserType.STUDENT;

        // Call the method to register the existing user
        try {
            system.addUser(existingUserId, existingUserPassword, existingUserType);
            // Test fails if user registration process is completed successfully with existing user ID
            // You can also add assertions to check for expected error messages or exceptions
        } catch (Exception e) {
            // Test passes if an exception is thrown as expected
        }
    }
    // Positive User Registration Test - Successful registration of a new user
    @Test
    public void positiveLecturerUserRegistrationTest() {
        // Simulate user registration process
        // For example, let's attempt to register a new user
        String newUserId = "newUser";
        String newUserPassword = "newPassword";
        UserType newUserType = UserType.LECTURER;

        // Call the method to register the new user
        try {
            system.addUser(newUserId, newUserPassword, newUserType);
            // Assuming the new user is successfully registered without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the user registration process
            // You can also add assertions to provide more specific information about the failure
        }
    }

    // Negative User Registration Test - Failed registration of a new user
    @Test
    public void negativeLecturerUserRegistrationTest() {
        // Simulate user registration process with existing user ID
        // For example, let's attempt to register a user with an existing user ID
        String existingUserId = "existingUser";
        String existingUserPassword = "existingPassword";
        UserType existingUserType = UserType.LECTURER;

        // Call the method to register the existing user
        try {
            system.addUser(existingUserId, existingUserPassword, existingUserType);
            // Test fails if user registration process is completed successfully with existing user ID
            // You can also add assertions to check for expected error messages or exceptions
        } catch (Exception e) {
            // Test passes if an exception is thrown as expected
        }
    }
    // Positive User Registration Test - Successful registration of a new user
    @Test
    public void positiveAdminUserRegistrationTest() {
        // Simulate user registration process
        // For example, let's attempt to register a new user
        String newUserId = "newUser";
        String newUserPassword = "newPassword";
        UserType newUserType = UserType.ADMIN;

        // Call the method to register the new user
        try {
            system.addUser(newUserId, newUserPassword, newUserType);
            // Assuming the new user is successfully registered without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the user registration process
            // You can also add assertions to provide more specific information about the failure
        }
    }

    // Negative User Registration Test - Failed registration of a new user
    @Test
    public void negativeAdminUserRegistrationTest() {
        // Simulate user registration process with existing user ID
        // For example, let's attempt to register a user with an existing user ID
        String existingUserId = "existingUser";
        String existingUserPassword = "existingPassword";
        UserType existingUserType = UserType.ADMIN;

        // Call the method to register the existing user
        try {
            system.addUser(existingUserId, existingUserPassword, existingUserType);
            // Test fails if user registration process is completed successfully with existing user ID
            // You can also add assertions to check for expected error messages or exceptions
        } catch (Exception e) {
            // Test passes if an exception is thrown as expected
        }
    }
    @Test
    public void testMakePayment_Positive() throws UniversityManagement.InsufficientPaymentException {
        system.makePayment(56000); // Attempt to make a payment with a positive integer amount
        assertTrue(system.isPaymentMade);
    }

    @Test
    public void testMakePayment_Negative() throws UniversityManagement.InsufficientPaymentException {
        try {
            system.makePayment(Double.parseDouble("InvalidAmount")); // Attempt to make a payment with a string amount
            assertFalse(system.isPaymentMade);
        }catch (Exception e){

        }
    }
}
