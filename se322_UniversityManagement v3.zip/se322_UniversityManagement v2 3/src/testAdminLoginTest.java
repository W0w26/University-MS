import org.junit.Test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

public class testAdminLoginTest {
    UniversityManagement system = new UniversityManagement();
    @Test
    public void positiveAdminLoginTest() {
        // Create a test user with valid credentials
        User testUser = new User("validUser", "password123", UserType.ADMIN);

        // Add the test user to the system
        system.addUser(testUser.getId(), testUser.getPassword(), testUser.getType());

        // Attempt to login with the valid credentials
        User loggedInUser = system.login("validUser", "password123");

        // Assert that the loggedInUser object is not null
        assertNotNull(loggedInUser, "Positive login test failed for valid credentials for Admins.");
    }

    // Negative Login Test - Invalid user credentials
    @Test
    public void negativeAdminLoginTest() {
        createTestUsersFile(); // Create test users file
        User invalidUser = system.login("invalidUser", "wrongpassword");
        assertNull(invalidUser, "Negative login test failed for invalid credentials for Admins.");
        deleteTestUsersFile(); // Delete test users file
    }
    // Helper method to create a test users file
    private void createTestUsersFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("test_users.txt"))) {
            writer.write("validUser,password123,STUDENT\n");
            writer.write("adminUser,adminPassword,ADMIN\n");
            // Add more test users if needed
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Helper method to delete the test users file
    private void deleteTestUsersFile() {
        File file = new File("test_users.txt");
        if (file.exists()) {
            file.delete();
        }
    }
}
