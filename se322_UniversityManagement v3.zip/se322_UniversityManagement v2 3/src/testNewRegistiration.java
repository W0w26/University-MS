import org.junit.Test;

public class testNewRegistiration {
    UniversityManagement system = new UniversityManagement();
    // Positive New Course Registration Test - Successful registration of a new course
    @Test
    public void positiveNewCourseRegistrationTest() {
        // Simulate course registration process
        // For example, let's register a new course
        String newCourse = "New Course"; // New course name

        // Call the method to register the new course
        try {
            system.addCourse(newCourse);
            // Assuming the new course is successfully registered without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the course registration process
            // You can also add assertions to provide more specific information about the failure
        }
    }


    // Negative New Course Registration Test - Failed registration of a new course
    @Test
    public void negativeNewCourseRegistrationTest() {
        // Simulate course registration process with existing course name
        // For example, let's try to register a course with a name that already exists in the system
        String existingCourse = "Existing Course"; // Existing course name

        // Call the method to register the existing course
        try {
            system.addCourse(existingCourse);
            // Assuming the course registration process encounters an error and throws an exception
            // Test passes if expected error message is displayed or exception is thrown
        } catch (Exception e) {
            // Test passes if an exception is thrown during the course registration process
            // You can also add assertions to verify the specific type of exception or error message
        }
    }
}
