import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class testConvertToLetterGrade {

    UniversityManagement system = new UniversityManagement();

    @Test
    public void testConvertToLetterGrade_Positive() {
        // for Test A
        assertEquals("A", system.convertToLetterGrade(95));
        assertEquals("A", system.convertToLetterGrade(90));
        assertEquals("A", system.convertToLetterGrade(91));

        // for Test B
        assertEquals("B", system.convertToLetterGrade(85));
        assertEquals("B", system.convertToLetterGrade(80));
        assertEquals("B", system.convertToLetterGrade(89));

        // for Test C
        assertEquals("C", system.convertToLetterGrade(75));
        assertEquals("C", system.convertToLetterGrade(70));
        assertEquals("C", system.convertToLetterGrade(79));

        // for Test D
        assertEquals("D", system.convertToLetterGrade(65));
        assertEquals("D", system.convertToLetterGrade(60));
        assertEquals("D", system.convertToLetterGrade(69));

        // for Test F
        assertEquals("F", system.convertToLetterGrade(55));
        assertEquals("F", system.convertToLetterGrade(0));
        assertEquals("F", system.convertToLetterGrade(59));
    }
    @Test
    public void testConvertToLetterGrade_Negative() {
        // for Test A
        assertEquals("A", system.convertToLetterGrade(90));

        // for Test B
        assertEquals("B", system.convertToLetterGrade(80));

        // for Test C
        assertEquals("C", system.convertToLetterGrade(70));

        // for Test D
        assertEquals("D", system.convertToLetterGrade(60));

        // for Test F
        assertEquals("F", system.convertToLetterGrade(59));
        assertEquals("F", system.convertToLetterGrade(0));
    }
}
