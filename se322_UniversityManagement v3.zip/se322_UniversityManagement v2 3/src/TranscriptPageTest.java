import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TranscriptPageTest {

    private User user1;
    private User user2;

    @BeforeEach
    void setUp() throws IOException {
        // Create a user with grades
        user1 = new User("12345", "12345", UserType.STUDENT);
        // Create a user without grades
        user2 = new User("67890", "67890", UserType.STUDENT);

        // Create a mock GradedCourse.txt file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("GradedCourse.txt"))) {
            writer.write("12345,Math,95\n");
            writer.write("12345,Science,85\n");
        }
    }

    @AfterEach
    void tearDown() {
        // Clean up the mock GradedCourse.txt file
        File file = new File("GradedCourse.txt");
        if (file.exists()) {
            file.delete();
        }
    }

    @Test
    public void testOpenTranscriptPageWithGrades() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            JFrame frame = new JFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JPanel panel = new JPanel(new BorderLayout());

            JTextArea textArea = new JTextArea();
            textArea.setEditable(false);

            try (BufferedReader br = new BufferedReader(new FileReader("GradedCourse.txt"))) {
                StringBuilder transcriptText = new StringBuilder();
                String line;
                boolean hasGrades = false;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 3 && parts[0].equals(user1.getId())) {
                        String courseName = parts[1];
                        double numericGrade = Double.parseDouble(parts[2]);
                        String letterGrade = convertToLetterGrade(numericGrade);
                        transcriptText.append(courseName).append(": ").append(letterGrade).append("\n");
                        hasGrades = true;
                    }
                }
                if (!hasGrades) {
                    transcriptText.append("No grades found for the user.");
                }
                textArea.setText(transcriptText.toString());
            } catch (IOException ex) {
                ex.printStackTrace();
            }

            JScrollPane scrollPane = new JScrollPane(textArea);
            panel.add(scrollPane, BorderLayout.CENTER);
            frame.add(panel);
            frame.pack();
            frame.setVisible(true);

            // Assert the text area content
            String expectedTranscript = "Math: A\nScience: B\n";
            assertEquals(expectedTranscript, textArea.getText());
        });
    }

    @Test
    public void testOpenTranscriptPageWithoutGrades() throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            JFrame frame = new JFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JPanel panel = new JPanel(new BorderLayout());

            JTextArea textArea = new JTextArea();
            textArea.setEditable(false);

            try (BufferedReader br = new BufferedReader(new FileReader("GradedCourse.txt"))) {
                StringBuilder transcriptText = new StringBuilder();
                String line;
                boolean hasGrades = false;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 3 && parts[0].equals(user2.getId())) {
                        String courseName = parts[1];
                        double numericGrade = Double.parseDouble(parts[2]);
                        String letterGrade = convertToLetterGrade(numericGrade);
                        transcriptText.append(courseName).append(": ").append(letterGrade).append("\n");
                        hasGrades = true;
                    }
                }
                if (!hasGrades) {
                    transcriptText.append("No grades found for the user.");
                }
                textArea.setText(transcriptText.toString());
            } catch (IOException ex) {
                ex.printStackTrace();
            }

            JScrollPane scrollPane = new JScrollPane(textArea);
            panel.add(scrollPane, BorderLayout.CENTER);
            frame.add(panel);
            frame.pack();
            frame.setVisible(true);

            // Assert the text area content
            String expectedTranscript = "No grades found for the user.";
            assertEquals(expectedTranscript, textArea.getText());
        });
    }

    private String convertToLetterGrade(double numericGrade) {
        if (numericGrade >= 90) {
            return "A";
        } else if (numericGrade >= 80) {
            return "B";
        } else if (numericGrade >= 70) {
            return "C";
        } else if (numericGrade >= 60) {
            return "D";
        } else {
            return "F";
        }
    }
}
