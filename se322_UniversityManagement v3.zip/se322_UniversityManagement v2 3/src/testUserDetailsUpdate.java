import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

public class testUserDetailsUpdate {

    UniversityManagement system = new UniversityManagement();
    @Test
    public void positiveUserDetailsUpdateTest() {
        // Creating a test user with username "testUser", password "password123", and user type STUDENT
        User testUser = new User("testUser", "password123", UserType.STUDENT);
        // Adding the test user to the system
        system.addUser(testUser.getId(), testUser.getPassword(), testUser.getType());
        // Creating an updated user with the same username "testUser" but with a new password "newPassword123" and user type STUDENT
        User updatedUser = new User("testUser", "newPassword123", UserType.STUDENT);
        // Updating the user information in the system file
        system.updateUserInfoInFile(updatedUser);
        // Checking if the user update operation is successful
        assertNotNull(updatedUser, "Positive user details update test failed.");
    }

    @Test
    public void negativeUserDetailsUpdateTest() {
        // Create a test user, but do not add this user to the system
        User testUser = new User("testUser", "password123", UserType.STUDENT);

        // Attempt to update the user (a user that does not exist in the system)
        system.updateUserInfoInFile(testUser);

        // Since the update should fail, the retrieved user should be null
        User retrievedUser = system.getUserById(testUser.getId());
        assertNull(retrievedUser, "Negative user details update test failed.");
    }

}
