import org.junit.Test;
import static org.junit.Assert.*;

public class testUserPassword {

    @Test
    public void testGetPassword_Positive() {
        // Arrange
        String id = "john_doe";
        String password = "securePassword123";
        UserType type = UserType.STUDENT;
        User user = new User(id, password, type);

        // Act
        String retrievedPassword = user.getPassword();

        // Assert
        assertEquals(password, retrievedPassword);
    }

    @Test
    public void testGetPassword_Negative() {
        // Arrange
        String id = "john_doe";
        String password = null;
        UserType type = UserType.STUDENT;
        User user = new User(id, password, type);

        // Act
        String retrievedPassword = user.getPassword();

        // Assert
        assertNull(retrievedPassword);
    }
}