import org.junit.Test;

import javax.swing.*;
import java.awt.*;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

public class testOpenEventDialog {
    public UniversityManagement system = new UniversityManagement();

    @Test
    public void testOpenEventsDialog_Positive() {
        SwingUtilities.invokeLater(() -> {

            // Call the method to open the events dialog
            system.openEventsDialog(new User("testUser", "password", UserType.STUDENT));

            // Check if the frame is created and visible
            Frame[] frames = Frame.getFrames();
            JFrame eventsFrame = null;
            for (Frame frame : frames) {
                if (frame.getTitle().equals("Events")) {
                    eventsFrame = (JFrame) frame;
                    break;
                }
            }
            assertNotNull(eventsFrame); // Ensure the frame is not null
            assertTrue(eventsFrame.isVisible()); // Ensure the frame is visible
        });
    }
    @Test
    public void testOpenEventsDialog_Negative() {
        SwingUtilities.invokeLater(() -> {
            // Call the method to open the events dialog
            system.openEventsDialog(new User("testUser", "password", UserType.STUDENT));

            // Check if the frame is not created
            Frame[] frames = Frame.getFrames();
            JFrame eventsFrame = null;
            for (Frame frame : frames) {
                if (frame.getTitle().equals("Events")) {
                    eventsFrame = (JFrame) frame;
                    break;
                }
            }
            assertNull(eventsFrame); // Ensure the frame is null
        });
    }
}
