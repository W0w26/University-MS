import org.junit.Test;

public class testAdminUserRegistiration {
    UniversityManagement system = new UniversityManagement();

    // Positive User Registration Test - Successful registration of a new user
    @Test
    public void positiveAdminUserRegistrationTest() {
        // Simulate user registration process
        // For example, let's attempt to register a new user
        String newUserId = "newUser";
        String newUserPassword = "newPassword";
        UserType newUserType = UserType.ADMIN;

        // Call the method to register the new user
        try {
            system.addUser(newUserId, newUserPassword, newUserType);
            // Assuming the new user is successfully registered without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the user registration process
            // You can also add assertions to provide more specific information about the failure
        }
    }

    // Negative User Registration Test - Failed registration of a new user
    @Test
    public void negativeAdminUserRegistrationTest() {
        // Simulate user registration process with existing user ID
        // For example, let's attempt to register a user with an existing user ID
        String existingUserId = "existingUser";
        String existingUserPassword = "existingPassword";
        UserType existingUserType = UserType.ADMIN;

        // Call the method to register the existing user
        try {
            system.addUser(existingUserId, existingUserPassword, existingUserType);
            // Test fails if user registration process is completed successfully with existing user ID
            // You can also add assertions to check for expected error messages or exceptions
        } catch (Exception e) {
            // Test passes if an exception is thrown as expected
        }
    }
}
