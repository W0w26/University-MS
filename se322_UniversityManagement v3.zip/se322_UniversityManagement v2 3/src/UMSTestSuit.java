import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        testAdminLoginTest.class,
        testAdminUserRegistiration.class,
        testAnnouncementEdit.class,
        testAnnouncementSaving.class,
        testAttendanceRecord.class,
        testAuthenticate.class,
        testConvertToLetterGrade.class,
        testCourseAddition.class,
        testCourseSelection.class,
        testGetUserById.class,
        testGradeDisplay.class,
        testGradeEntry.class,
        testInfoEvent.class,
        testInfoExam.class,
        testLecturerLogin.class,
        testLecturerUserRegistiration.class,
        testNewRegistiration.class,
        testOpenEventDialog.class,
        testOpenExamInformationDisplay.class,
        testOpenTestInfoDialog.class,
        testPasswordComplexityAdmin.class,
        testPasswordComplexityLecturer.class,
        testPasswordComplexityStudent.class,
        testPayment.class,
        testPaymentGUI.class,
        testStudentLogin.class,
        testStudentUserRegistiration.class,
        testUserDetailsUpdate.class,
        testUserID.class,
        testUserPassword.class,
})
public class UMSTestSuit {

}
