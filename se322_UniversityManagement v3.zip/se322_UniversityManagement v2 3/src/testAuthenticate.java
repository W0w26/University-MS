import org.junit.Test;
import static org.junit.Assert.*;

public class testAuthenticate {
    @Test
    public void testAuthenticate_Positive() {
        // Arrange
        String id = "john_doe";
        String password = "securePassword123";
        UserType type = UserType.STUDENT;
        User user = new User(id, password, type);

        // Act
        boolean isAuthenticated = user.authenticate("securePassword123");

        // Assert
        assertTrue(isAuthenticated);
    }
    @Test
    public void testAuthenticate_Negative() {
        // Arrange
        String id = "john_doe";
        String password = "securePassword123";
        UserType type = UserType.STUDENT;
        User user = new User(id, password, type);

        // Act
        boolean isAuthenticated = user.authenticate("wrongPassword");

        // Assert
        assertFalse(isAuthenticated);
    }
}
