import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

// Enum for user types
enum UserType {
    STUDENT, LECTURER, ADMIN
}

// Class to represent a User
class User {
    private String id;
    private String password;
    private UserType type;

    public User(String id, String password, UserType type) {
        this.id = id;
        this.password = password;
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public UserType getType() {
        return type;
    }

    // Method to authenticate user
    public boolean authenticate(String enteredPassword) {
        return this.password.equals(enteredPassword);
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

// Class to represent the University Management System GUI
public class UniversityManagement {
    private List<String> courses = new ArrayList<>();
    private List<User> users;
    private JFrame currentFrame; // To keep track of the current frame
    boolean isPaymentMade;

    public UniversityManagement() {
        users = new ArrayList<>();
    }

    // Method to add a user
    public void addUser(String id, String password, UserType type) {
        users.add(new User(id, password, type));
    }

    // Method to handle user login
    public User login(String id, String password) {
        for (User user : users) {
            if (user.getId().equals(id) && user.authenticate(password)) {
                return user;
            }
        }
        return null;
    }

    // Method to load users from a text file
    public void loadUsersFromFile(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String id = parts[0];
                    String password = parts[1];
                    UserType type = UserType.valueOf(parts[2]);
                    addUser(id, password, type);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to save users to a text file
    public void saveUsersToFile(String filename, User user) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true))) {
            bw.write(user.getId() + "," + user.getPassword() + "," + user.getType().toString());
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to create and configure a frame
    private JFrame createFrame(String title, int width, int height) {
        JFrame frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(width, height);
        frame.setLocationRelativeTo(null); // Center the frame on the screen
        return frame;
    }

    // Method to open the student home page
    public void openStudentHomePage(User user) {
        currentFrame.dispose(); // Close the current frame

        JFrame studentFrame = createFrame("Student Home Page", 1200, 800);
        currentFrame = studentFrame; // Update the current frame

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JLabel label = new JLabel("Welcome, " + user.getId() + "!");
        panel.add(label, BorderLayout.NORTH);

        // Panel for buttons (flow layout)
        JPanel buttonPanel = new JPanel(new FlowLayout());

        // Add Course Selection button
        JButton courseSelectionButton = new JButton("Course Selection");
        courseSelectionButton.setPreferredSize(new Dimension(120, 30));
        buttonPanel.add(courseSelectionButton);

        // Add logout button
        JButton logoutButton = new JButton("Logout");
        logoutButton.setPreferredSize(new Dimension(120, 30));
        buttonPanel.add(logoutButton);

        JButton attendanceButton = new JButton("Attendance");
        attendanceButton.setPreferredSize(new Dimension(120, 30));
        buttonPanel.add(attendanceButton);

        JButton paymentButton = new JButton("Make Payment");
        paymentButton.setPreferredSize(new Dimension(120, 30));
        buttonPanel.add(paymentButton);

        // Add Transcript button
        JButton transcriptButton = new JButton("Transcript");
        transcriptButton.setPreferredSize(new Dimension(120, 30));
        buttonPanel.add(transcriptButton);

        // Add Exam Information Display button
        JButton examInfoDisplayButton = new JButton("Exam Information Display");
        examInfoDisplayButton.setPreferredSize(new Dimension(120, 30));
        buttonPanel.add(examInfoDisplayButton);

        // Add events button
        JButton eventsButton = new JButton("Events");
        eventsButton.setPreferredSize(new Dimension(120, 30));
        buttonPanel.add(eventsButton);

        // Add Change Info button
        JButton changeInfoButton = new JButton("Change Info");
        changeInfoButton.setPreferredSize(new Dimension(120, 30));
        buttonPanel.add(changeInfoButton);

        // Add action listener for events button
        eventsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open events dialog
                openEventsDialog(user);
            }
        });

        // Add action listeners
        attendanceButton.addActionListener(e -> openAttendanceDialog(user.getId()));
        paymentButton.addActionListener(e -> openPaymentPage(user));

        courseSelectionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open course selection dialog
                openCourseSelectionDialog(currentFrame, user);
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Go back to login screen
                openLoginScreen();
            }
        });

        transcriptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open transcript page
                openTranscriptPage(user);
            }
        });
        examInfoDisplayButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open exam information display page
                openExamInformationDisplayPage();
            }
        });

        // Add action listener for Change Info button
        changeInfoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open change info dialog
                openChangeInfoDialog(user);
            }
        });

        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Panel to display enrolled courses and grades
        JPanel coursePanel = new JPanel();
        coursePanel.setLayout(new GridLayout(0, 2));

        // Load enrolled courses and grades from file
        try (BufferedReader br = new BufferedReader(new FileReader("GradedCourse.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[0].equals(user.getId())) {
                    String courseName = parts[1];
                    JButton gradeButton = new JButton("See the Grade");
                    gradeButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            // Open grade display dialog
                            openGradeDisplayDialog(user.getId(), courseName);
                        }
                    });
                    gradeButton.setPreferredSize(new Dimension(30, 7)); // Resize button here
                    coursePanel.add(new JLabel(courseName));
                    coursePanel.add(gradeButton);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        panel.add(coursePanel, BorderLayout.CENTER);

        // Panel for announcements
        JPanel announcementPanel = new JPanel(new BorderLayout());

        // Read announcements from file and display them
        try (BufferedReader br = new BufferedReader(new FileReader("announcement.txt"))) {
            StringBuilder announcementsText = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                announcementsText.append(line).append("\n");
            }

            JTextArea announcementsTextArea = new JTextArea(10, 30);
            announcementsTextArea.setText(announcementsText.toString());
            announcementsTextArea.setEditable(false);

            JScrollPane scrollPane = new JScrollPane(announcementsTextArea);
            announcementPanel.add(new JLabel("Announcements"), BorderLayout.NORTH);
            announcementPanel.add(scrollPane, BorderLayout.CENTER);
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        panel.add(announcementPanel, BorderLayout.WEST);

        studentFrame.add(panel);
        studentFrame.setVisible(true);
    }
    public void openAttendanceDialog(String userId) {
        StringBuilder attendanceBuilder = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader("devamsizlik.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4 && parts[1].equals(userId)) {
                    String courseName = parts[0];
                    String date = parts[2];
                    String absenceTime = parts[3];
                    attendanceBuilder.append("Course: ").append(courseName)
                            .append(", Date: ").append(date)
                            .append(", Absence Time: ").append(absenceTime)
                            .append("\n");
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        JOptionPane.showMessageDialog(currentFrame, attendanceBuilder.toString(), "Attendance Information", JOptionPane.INFORMATION_MESSAGE);
    }


    // Method to open grade display dialog
    public void openGradeDisplayDialog(String userId, String courseName) {
        // Load grades for the course
        StringBuilder gradesBuilder = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader("GradedCourse.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[0].equals(userId) && parts[1].equals(courseName)) {
                    gradesBuilder.append("Grade: ").append(parts[2]).append("\n");
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        JOptionPane.showMessageDialog(currentFrame, gradesBuilder.toString(), "Grades for " + courseName, JOptionPane.INFORMATION_MESSAGE);

    }
    protected void openPaymentPage(User user) {
        // Create a new JFrame
        JFrame paymentFrame = createFrame("Payment Page", 400, 300);

        // Create a main panel
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // user information label
        JLabel userInfoLabel = new JLabel("Payment for: " + user.getId());
        panel.add(userInfoLabel, BorderLayout.NORTH);

        // payment panel
        JPanel paymentFormPanel = new JPanel();
        paymentFormPanel.setLayout(new GridLayout(3, 2));

        // Determine the amount to be paid
        JLabel amountLabel = new JLabel("Amount to Pay:");
        JTextField amountField = new JTextField(10);
        paymentFormPanel.add(amountLabel);
        paymentFormPanel.add(amountField);

        panel.add(paymentFormPanel, BorderLayout.CENTER);

        // Payment button
        JButton payButton = new JButton("Pay");
        payButton.addActionListener(e -> {
            // Take payment
            String amountText = amountField.getText();
            double amountToPay = Double.parseDouble(amountText);

            // Make Payment
            try {
                makePayment(amountToPay);
            } catch (InsufficientPaymentException ex) {
                throw new RuntimeException(ex);
            }
            double requiredPayment = 56000;
            double remainingPayment = requiredPayment - amountToPay;

            // Payment success message
            JOptionPane.showMessageDialog(paymentFrame, "Payment successful!\n Please pay the remaining amount: " + remainingPayment , "Payment Status", JOptionPane.INFORMATION_MESSAGE);
            paymentFrame.dispose(); // close the payment Frame
        });

        panel.add(payButton, BorderLayout.SOUTH);

        // If payment is not done show the message
        if (isPaymentMade) {
            JLabel paymentMadeLabel = new JLabel("Payment has already been made.");
            panel.add(paymentMadeLabel, BorderLayout.CENTER);
            payButton.setEnabled(false); // Disable the payment button
        }

        paymentFrame.add(panel);
        paymentFrame.setVisible(true);
    }

    public void makePayment(double amountToPay) throws InsufficientPaymentException {
        // Assuming the required payment amount is 56000
        double requiredPayment = 56000;

        // Check if the amount to pay is sufficient
        if (amountToPay >= requiredPayment) {
            // Payment successful
            isPaymentMade = true;
        } else {
            // Payment insufficient

            // Print or log the remaining amount without throwing an exception
            System.out.println("Insufficient payment");
        }
    }

    class InsufficientPaymentException extends Exception {
        public InsufficientPaymentException(String message) {
            super(message);
        }
    }

    // Method to open the lecturer home page
    public void openLecturerHomePage(User user) {
        currentFrame.dispose(); // Close the current frame

        JFrame lecturerFrame = createFrame("Lecturer Home Page", 600, 400);
        currentFrame = lecturerFrame; // Update the current frame

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JLabel label = new JLabel("Welcome, " + user.getId() + "!");
        panel.add(label, BorderLayout.CENTER);

        // Panel for buttons (flow layout)
        JPanel buttonPanel = new JPanel(new FlowLayout());

        // Add Course Addition button
        JButton courseAddButton = new JButton("Add Course");
        courseAddButton.setPreferredSize(new Dimension(120, 30));
        buttonPanel.add(courseAddButton);

        // Add Add Grade button
        JButton addGradeButton = new JButton("Add Grade");
        addGradeButton.setPreferredSize(new Dimension(120, 30));
        buttonPanel.add(addGradeButton);

        // Add logout button
        JButton logoutButton = new JButton("Logout");
        logoutButton.setPreferredSize(new Dimension(120, 30));
        buttonPanel.add(logoutButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Add action listener to Course Addition button
        courseAddButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openCourseRegistrationDialog();
            }
        });

        // Add action listener to Add Grade button
        addGradeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openGradeEntryDialog(user);
            }
        });

        // Add action listener to logout button
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Go back to login screen
                openLoginScreen();
            }
        });

        lecturerFrame.add(panel);
        lecturerFrame.setVisible(true);

        // Create button for attendance record
        JButton attendanceRecordButton = new JButton("Record Attendance");
        attendanceRecordButton.setPreferredSize(new Dimension(180, 30));
        buttonPanel.add(attendanceRecordButton);

        // Add action listener to attendance record button
        attendanceRecordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Prompt user for course, student, date, and attendance count
                String course = JOptionPane.showInputDialog(lecturerFrame, "Enter Course:");
                String student = JOptionPane.showInputDialog(lecturerFrame, "Enter Student:");
                String date = JOptionPane.showInputDialog(lecturerFrame, "Enter Date:");
                String attendanceCount = JOptionPane.showInputDialog(lecturerFrame, "Enter Attendance Count:");

                // Write attendance record to file
                try {
                    FileWriter writer = new FileWriter("devamsizlik.txt", true);
                    writer.write(course + "," + student + ", " + date + ", " + attendanceCount + "\n");
                    writer.close();
                    JOptionPane.showMessageDialog(lecturerFrame, "Attendance recorded successfully!");
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(lecturerFrame, "Error occurred while recording attendance!");
                }
            }
        });
    }

    // Method to open the admin home page
// Method to open registration dialog for new users (admin feature)
    public void openRegistrationDialog() {
        JFrame registrationFrame = createFrame("New Registration", 300, 200);
        JPanel registrationPanel = new JPanel();
        registrationPanel.setLayout(new GridLayout(4, 2));

        JLabel idLabel = new JLabel("User ID:");
        JTextField idField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();
        JLabel typeLabel = new JLabel("User Type:");
        JComboBox<UserType> typeComboBox = new JComboBox<>(UserType.values());

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = idField.getText();
                String password = new String(passwordField.getPassword());
                UserType type = (UserType) typeComboBox.getSelectedItem();

                if (id.isEmpty() || password.isEmpty() || type == null) {
                    JOptionPane.showMessageDialog(registrationFrame, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                User newUser = new User(id, password, type);
                addUser(id, password, type);
                saveUsersToFile("users.txt", newUser);
                JOptionPane.showMessageDialog(registrationFrame, "User registered successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                registrationFrame.dispose();
            }
        });

        registrationPanel.add(idLabel);
        registrationPanel.add(idField);
        registrationPanel.add(passwordLabel);
        registrationPanel.add(passwordField);
        registrationPanel.add(typeLabel);
        registrationPanel.add(typeComboBox);
        registrationPanel.add(new JLabel()); // Placeholder
        registrationPanel.add(registerButton);

        registrationFrame.add(registrationPanel);
        registrationFrame.setVisible(true);
    }

    // Modify openAdminHomePage to include the registration feature
    public void openAdminHomePage(User user) {
        currentFrame.dispose(); // Close the current frame

        JFrame adminFrame = createFrame("Admin Home Page", 600, 400);
        currentFrame = adminFrame; // Update the current frame

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JButton addExamButton = new JButton("Add Exam Information");
        addExamButton.setPreferredSize(new Dimension(200, 50)); // Reduce button size
        addExamButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openExamInformationPage();
            }
        });
        panel.add(addExamButton, BorderLayout.WEST);

        JButton registerButton = new JButton("New Registration");
        registerButton.setPreferredSize(new Dimension(100, 50)); // Reduce button size
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openRegistrationDialog();
            }
        });
        panel.add(registerButton, BorderLayout.NORTH);

        JButton announcementButton = new JButton("Edit Announcement");
        announcementButton.setPreferredSize(new Dimension(200, 50)); // Reduce button size
        panel.add(announcementButton, BorderLayout.CENTER);

        announcementButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame editAnnouncementFrame = createFrame("Edit Announcement", 400, 200);
                JPanel editAnnouncementPanel = new JPanel();
                editAnnouncementPanel.setLayout(new GridLayout(3, 2));

                JLabel announcementNumberLabel = new JLabel("Announcement Number:");
                JTextField announcementNumberField = new JTextField();
                JLabel announcementContentLabel = new JLabel("Announcement Content:");
                JTextArea announcementContentArea = new JTextArea();
                announcementContentArea.setLineWrap(true); // Wrap text

                editAnnouncementPanel.add(announcementNumberLabel);
                editAnnouncementPanel.add(announcementNumberField);
                editAnnouncementPanel.add(announcementContentLabel);
                editAnnouncementPanel.add(announcementContentArea);

                JButton saveButton = new JButton("Save");
                saveButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String announcementNumber = announcementNumberField.getText();
                        String announcementContent = announcementContentArea.getText();

                        // Save announcement to file
                        saveAnnouncementToFile("announcement.txt", announcementNumber, announcementContent);

                        JOptionPane.showMessageDialog(null, "Announcement saved successfully.");
                        editAnnouncementFrame.dispose();
                    }
                });

                JButton cancelButton = new JButton("Cancel");
                cancelButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        editAnnouncementFrame.dispose();
                    }
                });

                editAnnouncementPanel.add(saveButton);
                editAnnouncementPanel.add(cancelButton);

                editAnnouncementFrame.add(editAnnouncementPanel);
                editAnnouncementFrame.setVisible(true);
            }
        });

        JButton logoutButton = new JButton("Logout");
        logoutButton.setPreferredSize(new Dimension(200, 50)); // Reduce button size
        panel.add(logoutButton, BorderLayout.SOUTH);

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openLoginScreen();
            }
        });

        JButton addEventButton = new JButton("Add New Event");
        addEventButton.setPreferredSize(new Dimension(200, 50));
        addEventButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame addEventFrame = createFrame("Add New Event", 400, 200);
                JPanel addEventPanel = new JPanel();
                addEventPanel.setLayout(new GridLayout(3, 2));

                JLabel eventNameLabel = new JLabel("Event Name:");
                JTextField eventNameField = new JTextField();
                JLabel eventDateLabel = new JLabel("Event Date (YYYY-MM-DD):");
                JTextField eventDateField = new JTextField();

                addEventPanel.add(eventNameLabel);
                addEventPanel.add(eventNameField);
                addEventPanel.add(eventDateLabel);
                addEventPanel.add(eventDateField);

                JButton saveButton = new JButton("Save");
                saveButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String eventName = eventNameField.getText();
                        String eventDate = eventDateField.getText();

                        // Validate event name and date
                        if (eventName.isEmpty() || eventDate.isEmpty()) {
                            JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                        } else {
                            // Save event to file or database
                            saveEventToFile("events.txt", eventName, eventDate);

                            JOptionPane.showMessageDialog(null, "Event added successfully.");
                            addEventFrame.dispose();
                        }
                    }

                    public static void saveEventToFile(String filename, String eventName, String eventDate) {
                        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
                            writer.write(eventName + "," + eventDate);
                            writer.newLine();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                });

                JButton cancelButton = new JButton("Cancel");
                cancelButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        addEventFrame.dispose();
                    }
                });

                addEventPanel.add(saveButton);
                addEventPanel.add(cancelButton);

                addEventFrame.add(addEventPanel);
                addEventFrame.setVisible(true);
            }
        });

        panel.add(addEventButton, BorderLayout.EAST);


        adminFrame.add(panel);
        adminFrame.setVisible(true);
    }

    public void openExamInformationPage() {
        JFrame examFrame = createFrame("Exam Information", 400, 300);
        JPanel examPanel = new JPanel();
        examPanel.setLayout(new GridLayout(5, 2));

        JLabel courseNameLabel = new JLabel("Course Name:");
        JTextField courseNameField = new JTextField();

        JLabel dateLabel = new JLabel("Date:");
        JTextField dateField = new JTextField();

        JLabel hourLabel = new JLabel("Hour:");
        JTextField hourField = new JTextField();

        JLabel classLabel = new JLabel("Class:");
        JTextField classField = new JTextField();

        examPanel.add(courseNameLabel);
        examPanel.add(courseNameField);
        examPanel.add(dateLabel);
        examPanel.add(dateField);
        examPanel.add(hourLabel);
        examPanel.add(hourField);
        examPanel.add(classLabel);
        examPanel.add(classField);

        JButton addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String courseName = courseNameField.getText();
                String date = dateField.getText();
                String hour = hourField.getText();
                String examClass = classField.getText();

                // Save the exam recording to file
                try {
                    // Boş girdi kontrolü
                    if (courseName.isEmpty() || date.isEmpty() || hour.isEmpty() || examClass.isEmpty()) {
                        throw new IllegalArgumentException("Incomplete information");
                    }

                    // Sınav bilgilerini dosyaya kaydet
                    saveExamInformationToFile("exam.txt", courseName, date, hour, examClass);

                    JOptionPane.showMessageDialog(null, "Exam information has been saved successfully.");
                    examFrame.dispose();
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(null, "Incomplete information. Please fill in all fields.");
                }


            }

        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                examFrame.dispose();
            }
        });

        examPanel.add(addButton);
        examPanel.add(cancelButton);

        examFrame.add(examPanel);
        examFrame.setVisible(true);
    }

    public void saveExamInformationToFile(String fileName, String courseName, String date, String hour, String examClass) {
        try {
            FileWriter writer = new FileWriter(fileName, true); // Append mode
            writer.write(courseName + ", " + date + ", " + hour + ", " + examClass + "\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // Method to append announcement to file
    protected void saveAnnouncementToFile(String fileName, String announcementNumber, String announcementContent) {
        // Append announcement to file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write("Announcement Number: " + announcementNumber);
            writer.newLine();
            writer.write("Announcement Content:");
            writer.newLine();
            writer.write(announcementContent);
            writer.newLine(); // Add newline after each announcement
            writer.newLine(); // Add an additional new line for readability between announcements
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to open the login screen
    public void openLoginScreen() {
        if (currentFrame != null) {
            currentFrame.dispose(); // Close the current frame
        }

        JFrame frame = createFrame("University Management System", 400, 200);
        currentFrame = frame; // Update the current frame

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));

        JLabel userLabel = new JLabel("User ID:");
        JTextField userIdField = new JTextField();
        JLabel passLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();
        JButton loginButton = new JButton("Login");
        JLabel statusLabel = new JLabel();

        panel.add(userLabel);
        panel.add(userIdField);
        panel.add(passLabel);
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(statusLabel);

        // Adding action listener to login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userId = userIdField.getText();
                String password = new String(passwordField.getPassword());
                User loggedInUser = login(userId, password);
                if (loggedInUser != null) {
                    statusLabel.setText("Login successful. User type: " + loggedInUser.getType());
                    // Redirect to different frames based on user type
                    switch (loggedInUser.getType()) {
                        case STUDENT:
                            openStudentHomePage(loggedInUser);
                            break;
                        case ADMIN:
                            openAdminHomePage(loggedInUser);
                            break;
                        case LECTURER:
                            openLecturerHomePage(loggedInUser);
                            break;
                    }
                } else {
                    statusLabel.setText("Login failed. Invalid credentials.");
                }
            }
        });

        // Displaying the frame
        frame.add(panel);
        frame.setVisible(true);
    }

    // course selection part
    public void openCourseSelectionDialog(JFrame currentFrame, User loggedInUser) {
        JFrame courseSelectionFrame = createFrame("Course Selection", 300, 200);
        JPanel courseSelectionPanel = new JPanel();
        courseSelectionPanel.setLayout(new GridLayout(3, 1));

        JComboBox<String> courseComboBox = new JComboBox<>();
        try (BufferedReader br = new BufferedReader(new FileReader("Courses.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                courseComboBox.addItem(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        courseSelectionPanel.add(courseComboBox);

        JButton selectButton = new JButton("Select");
        selectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedCourse = (String) courseComboBox.getSelectedItem();
                if (loggedInUser != null) {
                    String username = loggedInUser.getId();
                    String data = username + "," + selectedCourse;
                    writeToFile("StudentCourse.txt", data);
                    JOptionPane.showMessageDialog(null, "Course selected successfully.");
                    courseSelectionFrame.dispose();
                }
            }
        });

        courseSelectionPanel.add(selectButton);

        courseSelectionFrame.add(courseSelectionPanel);
        courseSelectionFrame.setVisible(true);
    }

    // Method to get user ID from frame title
    private String getUserID(String title, User loggedInUser) {
        if (loggedInUser != null) {
            return loggedInUser.getId();
        } else {
            // If the user is not logged in or the format is not as expected,
            // return a default value or handle the error
            return "Unknown";
        }
    }

    // Method to write data to file
    private void writeToFile(String filename, String data) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true))) {
            bw.write(data);
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to open course registration dialog for lecturers
    private void openCourseRegistrationDialog() {
        JFrame courseRegistrationFrame = createFrame("Course Registration", 300, 200);
        JPanel courseRegistrationPanel = new JPanel();
        courseRegistrationPanel.setLayout(new GridLayout(3, 1));

        JLabel courseLabel = new JLabel("Course:");
        JTextField courseField = new JTextField();

        JButton addButton = new JButton("Add Course");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String course = courseField.getText();
                if (!course.isEmpty()) {
                    addCourse(course);
                    JOptionPane.showMessageDialog(null, "Course added successfully.");
                    courseRegistrationFrame.dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a course name.");
                }
            }
        });

        courseRegistrationPanel.add(courseLabel);
        courseRegistrationPanel.add(courseField);
        courseRegistrationPanel.add(addButton);

        courseRegistrationFrame.add(courseRegistrationPanel);
        courseRegistrationFrame.setVisible(true);
    }

    // Method to open grade entry dialog
    protected void openGradeEntryDialog(User lecturer) {
        JFrame gradeEntryFrame = createFrame("Grade Entry", 300, 200);
        JPanel gradeEntryPanel = new JPanel();
        gradeEntryPanel.setLayout(new GridLayout(4, 1));

        JLabel courseLabel = new JLabel("Select Course:");
        JComboBox<String> courseComboBox = new JComboBox<>();
        // Load courses from Courses.txt
        try (BufferedReader br = new BufferedReader(new FileReader("Courses.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                courseComboBox.addItem(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        JLabel studentLabel = new JLabel("Select Student:");
        JComboBox<String> studentComboBox = new JComboBox<>();

        // Add item listener to courseComboBox to update studentComboBox
        courseComboBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    updateStudentList((String) courseComboBox.getSelectedItem(), studentComboBox);
                }
            }
        });

        // Initial student list based on the initially selected course
        updateStudentList((String) courseComboBox.getSelectedItem(), studentComboBox);

        JLabel gradeLabel = new JLabel("Enter Grade:");
        JTextField gradeField = new JTextField();

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedCourse = (String) courseComboBox.getSelectedItem();
                String selectedStudent = (String) studentComboBox.getSelectedItem();
                String grade = gradeField.getText();
                String data = selectedStudent + "," + selectedCourse + "," + grade;
                writeToFile("GradedCourse.txt", data);
                JOptionPane.showMessageDialog(null, "Grade added successfully.");
                gradeEntryFrame.dispose();
            }
        });

        gradeEntryPanel.add(courseLabel);
        gradeEntryPanel.add(courseComboBox);
        gradeEntryPanel.add(studentLabel);
        gradeEntryPanel.add(studentComboBox);
        gradeEntryPanel.add(gradeLabel);
        gradeEntryPanel.add(gradeField);
        gradeEntryPanel.add(submitButton);

        gradeEntryFrame.add(gradeEntryPanel);
        gradeEntryFrame.setVisible(true);
    }

    // Method to update student list based on selected course
    private void updateStudentList(String selectedCourse, JComboBox<String> studentComboBox) {
        studentComboBox.removeAllItems();
        // Load students enrolled in the selected course from StudentCourse.txt
        try (BufferedReader br = new BufferedReader(new FileReader("StudentCourse.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && parts[1].equals(selectedCourse)) {
                    studentComboBox.addItem(parts[0]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to add a course
    public void addCourse(String course) {
        // Load existing courses
        List<String> existingCourses = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("Courses.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                existingCourses.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Add the new course
        existingCourses.add(course);

        // Rewrite the courses file with updated list
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("Courses.txt"))) {
            for (String existingCourse : existingCourses) {
                bw.write(existingCourse);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    protected String convertToLetterGrade(double numericGrade) {
        if (numericGrade >= 90) {
            return "A";
        } else if (numericGrade >= 80) {
            return "B";
        } else if (numericGrade >= 70) {
            return "C";
        } else if (numericGrade >= 60) {
            return "D";
        } else {
            return "F";
        }
    }
    private void openTranscriptPage(User user) {
        JFrame transcriptFrame = createFrame("Transcript Page", 600, 400);

        JPanel transcriptPanel = new JPanel();
        transcriptPanel.setLayout(new BorderLayout());

        JTextArea transcriptTextArea = new JTextArea();
        transcriptTextArea.setEditable(false);

        // Load enrolled courses and grades from file
        try (BufferedReader br = new BufferedReader(new FileReader("GradedCourse.txt"))) {
            StringBuilder transcriptText = new StringBuilder();
            String line;
            boolean hasGrades = false;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[0].equals(user.getId())) {
                    String courseName = parts[1];
                    double numericGrade = Double.parseDouble(parts[2]);
                    String letterGrade = convertToLetterGrade(numericGrade);
                    transcriptText.append(courseName).append(": ").append(letterGrade).append("\n");
                    hasGrades = true;
                }
            }
            if (!hasGrades) {
                transcriptText.append("No grades found for the user.");
            }
            transcriptTextArea.setText(transcriptText.toString());
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        JScrollPane scrollPane = new JScrollPane(transcriptTextArea);
        transcriptPanel.add(scrollPane, BorderLayout.CENTER);

        transcriptFrame.add(transcriptPanel);
        transcriptFrame.setVisible(true);
    }
    // Function to open events dialog
    public void openEventsDialog(User user) {
        JFrame eventsFrame = createFrame("Events", 400, 300);

        JPanel eventsPanel = new JPanel();
        eventsPanel.setLayout(new GridLayout(0, 1));

        // Load events from file
        try (BufferedReader br = new BufferedReader(new FileReader("events.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String eventName = parts[0];
                    String eventDescription = parts[1];

                    JPanel eventPanel = new JPanel(new BorderLayout());

                    JLabel eventNameLabel = new JLabel(eventName);
                    eventPanel.add(eventNameLabel, BorderLayout.NORTH);

                    JTextArea eventDescriptionArea = new JTextArea(eventDescription);
                    eventDescriptionArea.setEditable(false);
                    eventPanel.add(eventDescriptionArea, BorderLayout.CENTER);

                    JButton joinButton = new JButton("Join");
                    joinButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            // Perform join action
                            // Example: Show success message
                            JOptionPane.showMessageDialog(eventsFrame, "You have successfully joined " + eventName);
                        }
                    });
                    eventPanel.add(joinButton, BorderLayout.EAST);

                    eventsPanel.add(eventPanel);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        JScrollPane scrollPane = new JScrollPane(eventsPanel);
        eventsFrame.add(scrollPane);
        eventsFrame.setVisible(true);
    }
    protected void openExamInformationDisplayPage() {
        JFrame examInfoFrame = createFrame("Exam Information Display", 600, 400);

        JTextArea examInfoTextArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(examInfoTextArea);

        try (BufferedReader br = new BufferedReader(new FileReader("exam.txt"))) {
            StringBuilder examInfoText = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                examInfoText.append(line).append("\n");
            }

            if (examInfoText.length() == 0) {
                examInfoTextArea.setText("There is no exam information.");
            } else {
                examInfoTextArea.setText(examInfoText.toString());
            }
        } catch (FileNotFoundException ex) {
            examInfoTextArea.setText("Exam information file not found.");
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        examInfoFrame.add(scrollPane);
        examInfoFrame.setVisible(true);
    }// Method to open the Change Info dialog
    protected void openChangeInfoDialog(User user) {
        JFrame changeInfoFrame = new JFrame("Change Info");
        JPanel panel = new JPanel(new GridLayout(3, 2));

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(user.getId());

        JLabel passwordLabel = new JLabel("Password:");
        JTextField passwordField = new JTextField(user.getPassword());

        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Save the changes
                user.setId(nameField.getText());
                user.setPassword(passwordField.getText());

                // Update the user information in users.txt
                updateUserInfoInFile(user);

                // Close the dialog
                changeInfoFrame.dispose();
            }
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Close the dialog without saving changes
                changeInfoFrame.dispose();
            }
        });

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(saveButton);
        panel.add(cancelButton);

        changeInfoFrame.add(panel);
        changeInfoFrame.pack();
        changeInfoFrame.setLocationRelativeTo(null); // Center the dialog on screen
        changeInfoFrame.setVisible(true);
    }

    // Method to update user information in users.txt file
    protected void updateUserInfoInFile(User user) {
        String filePath = "users.txt";
        String tempFilePath = "temp_users.txt";

        try (BufferedReader br = new BufferedReader(new FileReader(filePath));
             PrintWriter pw = new PrintWriter(new FileWriter(tempFilePath))) {

            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[0].equals(user.getId())) {
                    // Update the line with new name and password
                    pw.println(user.getId() + "," + user.getId() + "," + user.getPassword());
                } else {
                    pw.println(line);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        // Delete the original file
        File originalFile = new File(filePath);
        if (originalFile.exists()) {
            originalFile.delete();
        }

        // Rename the temporary file to the original file name
        File tempFile = new File(tempFilePath);
        if (tempFile.exists()) {
            tempFile.renameTo(originalFile);
        }
    }

    public User getUserById(String id) {
        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Each line is parsed and a user object is created
                String[] parts = line.split(",");
                if (parts[0].equals(id)) {
                    String password = parts[1];
                    UserType type = UserType.valueOf(parts[2]); // Convert user type to enum
                    return new User(id, password, type);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; // Return null if the user is not found
    }
    public static void main(String[] args) {
        UniversityManagement system = new UniversityManagement();
        // Load users from a file
        system.loadUsersFromFile("users.txt");

        // Open the login screen
        system.openLoginScreen();
    }
}