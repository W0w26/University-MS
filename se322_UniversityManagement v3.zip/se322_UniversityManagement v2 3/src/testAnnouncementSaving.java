import org.junit.Test;

public class testAnnouncementSaving {
    UniversityManagement system = new UniversityManagement();

    // Positive Announcement Saving Test - Successful saving of announcement
    @Test
    public void positiveAnnouncementSavingTest() {
        // Simulate announcement saving process
        // For example, let's attempt to save an announcement
        String announcementNumber = "1";
        String announcementContent = "Sample announcement content";

        // Call the method to save the announcement
        try {
            system.saveAnnouncementToFile("announcement.txt", announcementNumber, announcementContent);
            // Assuming the announcement saving process completes successfully without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the announcement saving process
            // You can also add assertions to provide more specific information about the failure
        }
    }

    // Negative Announcement Saving Test - Failed saving of announcement
    @Test
    public void negativeAnnouncementSavingTest() {
        // Simulate announcement saving process with invalid data or file permission issues
        // For example, let's attempt to save an announcement with invalid data
        String announcementNumber = "Invalid";
        String announcementContent = "Invalid announcement content";

        // Call the method to save the announcement with invalid data
        try {
            system.saveAnnouncementToFile("announcement.txt", announcementNumber, announcementContent);
            // Test fails if announcement saving process is completed successfully with invalid data
            // You can also add assertions to check for expected error messages or exceptions
        } catch (Exception e) {
            // Test passes if an exception is thrown as expected
        }
    }
}
