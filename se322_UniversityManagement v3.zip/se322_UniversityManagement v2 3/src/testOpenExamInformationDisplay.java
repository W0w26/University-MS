import org.junit.Test;

import javax.swing.*;
import java.awt.*;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

public class testOpenExamInformationDisplay {

    UniversityManagement system = new UniversityManagement();

    @Test
    public void testOpenExamInformationDisplayPage_Positive() {
        SwingUtilities.invokeLater(() -> {
            // Call the method to open the exam information display page
            system.openExamInformationDisplayPage();

            // Check if the frame is created and visible
            Frame[] frames = Frame.getFrames();
            JFrame examInfoFrame = null;
            for (Frame frame : frames) {
                if (frame.getTitle().equals("Exam Information Display")) {
                    examInfoFrame = (JFrame) frame;
                    break;
                }
            }
            assertNotNull(examInfoFrame); // Ensure the frame is not null
            assertTrue(examInfoFrame.isVisible()); // Ensure the frame is visible
        });
    }
    @Test
    public void testOpenExamInformationDisplayPage_Negative() {
        SwingUtilities.invokeLater(() -> {
            // Call the method to open the exam information display page
            system.openExamInformationDisplayPage();

            // Check if the frame is not created
            Frame[] frames = Frame.getFrames();
            JFrame examInfoFrame = null;
            for (Frame frame : frames) {
                if (frame.getTitle().equals("Exam Information Display")) {
                    examInfoFrame = (JFrame) frame;
                    break;
                }
            }
            assertNull(examInfoFrame); // Ensure the frame is null
        });
    }
}
