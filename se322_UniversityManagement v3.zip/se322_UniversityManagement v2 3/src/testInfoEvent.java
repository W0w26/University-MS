import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class testInfoEvent {
    @Test
    public void testCompleteInformation_Event() {
        String eventName = "Graduate";
        String eventDate = "2024-06-03";

        saveEventInformationToFile("events.txt", eventName, eventDate);

    }

    @Test
    public void testErrorMessage_Event() {
        // Arrange
        String eventName = "";
        String eventDate = "2024-06-03";

        ByteArrayOutputStream errContent = new ByteArrayOutputStream();
        System.setErr(new PrintStream(errContent));

        try {
            saveEventInformationToFile("events.txt", eventName, eventDate);
        } catch (IllegalArgumentException e) {
            // Assert
            assertEquals("Incomplete information", e.getMessage());
        }
    }
    public void saveEventInformationToFile(String fileName, String eventName, String eventDate) {
        if (eventName.isEmpty() || eventDate.isEmpty()) {
            throw new IllegalArgumentException("Incomplete information");
        }
    }
}
