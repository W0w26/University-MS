import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class testInfoExam {
    @Test
    public void testCompleteInformation_ExamInfo() {
        String courseName = "History";
        String date = "2024-06-02";
        String hour = "10:00";
        String examClass = "B202";

        saveExamInformationToFile("exam.txt", courseName, date, hour, examClass);

    }
    @Test
    public void testErrorMessage_ExamInfo() {
        // Arrange
        String courseName = "";
        String date = "";
        String hour = "";
        String examClass = "";

        ByteArrayOutputStream errContent = new ByteArrayOutputStream();
        System.setErr(new PrintStream(errContent));

        try {
            saveExamInformationToFile("exam.txt", courseName, date, hour, examClass);
        } catch (IllegalArgumentException e) {
            // Assert
            assertEquals("Incomplete information", e.getMessage());
        }
    }
    public void saveExamInformationToFile(String fileName, String courseName, String date, String hour, String examClass) {
        if (courseName.isEmpty() || date.isEmpty() || hour.isEmpty() || examClass.isEmpty()) {
            throw new IllegalArgumentException("Incomplete information");
        }
    }
}
