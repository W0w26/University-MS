import org.junit.Test;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.fail;

public class testGradeDisplay {
    // Display Grade
    @Test
    public void positiveGradeDisplayTest() {
        SwingUtilities.invokeLater(() -> {
            UniversityManagement gradeClass = new UniversityManagement();
            String userId = "123456";
            String courseName = "Math";
            String mockFileContent = "123456,Math,A\n123456,Science,B\n";

            // Mock BufferedReader to return the desired file content
            try (BufferedReader br = new BufferedReader(new StringReader(mockFileContent))) {
                BufferedReader originalBr = new BufferedReader(new FileReader("GradedCourse.txt"));
                new BufferedReader(new FileReader("GradedCourse.txt")) {
                    public String readLine() throws IOException {
                        return br.readLine();
                    }
                };

                gradeClass.openGradeDisplayDialog(userId, courseName);

                // Check if the JOptionPane is displayed with the correct message
                Frame[] frames = Frame.getFrames();
                JFrame gradeFrame = null;
                for (Frame frame : frames) {
                    if (frame instanceof JFrame && ((JFrame) frame).getTitle().equals("Grades for " + courseName)) {
                        gradeFrame = (JFrame) frame;
                        break;
                    }
                }
                assertNotNull(gradeFrame); // Ensure the frame is not null
                assertTrue(gradeFrame.isVisible()); // Ensure the frame is visible

                String expectedMessage = "Grade: A\n";
                JOptionPane pane = (JOptionPane) gradeFrame.getContentPane().getComponent(0);
                assertEquals(expectedMessage, pane.getMessage());
            } catch (IOException ex) {
                ex.printStackTrace();
                fail("An IOException was thrown: " + ex.getMessage());
            }
        });
    }

    @Test
    public void negativeGradeDisplayTest() {
        SwingUtilities.invokeLater(() -> {
            UniversityManagement gradeClass = new UniversityManagement();
            String userId = "invalidUserId";
            String courseName = "Math";
            String mockFileContent = "123456,Math,A\n123456,Science,B\n";

            // Mock BufferedReader to return the desired file content
            try (BufferedReader br = new BufferedReader(new StringReader(mockFileContent))) {
                BufferedReader originalBr = new BufferedReader(new FileReader("GradedCourse.txt"));
                new BufferedReader(new FileReader("GradedCourse.txt")) {
                    public String readLine() throws IOException {
                        return br.readLine();
                    }
                };

                gradeClass.openGradeDisplayDialog(userId, courseName);

                // Check if the JOptionPane is displayed with the correct message
                Frame[] frames = Frame.getFrames();
                JFrame gradeFrame = null;
                for (Frame frame : frames) {
                    if (frame instanceof JFrame && ((JFrame) frame).getTitle().equals("Grades for " + courseName)) {
                        gradeFrame = (JFrame) frame;
                        break;
                    }
                }
                assertNotNull(gradeFrame); // Ensure the frame is not null
                assertTrue(gradeFrame.isVisible()); // Ensure the frame is visible

                String expectedMessage = ""; // Since invalidUserId is used, no records should be found
                JOptionPane pane = (JOptionPane) gradeFrame.getContentPane().getComponent(0);
                assertEquals(expectedMessage, pane.getMessage());
            } catch (IOException ex) {
                ex.printStackTrace();
                fail("An IOException was thrown: " + ex.getMessage());
            }
        });
    }
}
