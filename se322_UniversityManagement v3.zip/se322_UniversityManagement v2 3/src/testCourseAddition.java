import org.junit.Test;

public class testCourseAddition {
    UniversityManagement system = new UniversityManagement();
    // Positive Course Addition Test - Successful addition of a new course
    @Test
    public void positiveCourseAdditionTest() {
        // Simulate course addition process
        // For example, let's attempt to add a new course
        String courseToAdd = "New Course";

        // Call the method to add the course
        try {
            system.addCourse(courseToAdd);
            // Assuming the course addition process completes successfully without exceptions
            // Test passes if no exceptions are thrown
        } catch (Exception e) {
            // Test fails if any exception is thrown during the course addition process
            // You can also add assertions to provide more specific information about the failure
        }
    }

    // Negative Course Addition Test - Failed addition of a new course
    @Test
    public void negativeCourseAdditionTest() {
        // Simulate course addition process with existing course name
        // For example, let's attempt to add an existing course
        String existingCourse = "Existing Course"; // Assuming "Existing Course" already exists

        // Call the method to add the existing course
        try {
            system.addCourse(existingCourse);
            // Test fails if course addition process is completed successfully with existing course name
            // You can also add assertions to check for expected error messages or exceptions
        } catch (Exception e) {
            // Test passes if an exception is thrown as expected
        }
    }
}
