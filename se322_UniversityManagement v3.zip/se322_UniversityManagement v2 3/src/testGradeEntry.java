import org.junit.Test;

public class testGradeEntry {
    UniversityManagement system = new UniversityManagement();
    // Positive Grade Entry Test - Valid grade entry
    @Test
    public void positiveGradeEntryTest() {
        // Create a test user
        User testUser = new User("testUser", "password123", UserType.LECTURER);
        system.addUser(testUser.getId(), testUser.getPassword(), testUser.getType());

        // Create a test course
        String testCourse = "Test Course";
        system.addCourse(testCourse);

        // Simulate grade entry dialog and grade submission
        system.openGradeEntryDialog(testUser);

        // Assuming the grade entry process completes successfully without exceptions
        // Test passes if no exceptions are thrown
    }

    // Negative Grade Entry Test - Invalid grade entry
    @Test
    public void negativeGradeEntryTest() {
        // Create a test user
        User testUser = new User("testUser", "password123", UserType.LECTURER);
        system.addUser(testUser.getId(), testUser.getPassword(), testUser.getType());

        // Create a test course
        String testCourse = "Test Course";
        system.addCourse(testCourse);

        // Simulate grade entry dialog with invalid data
        // For example, let's try to submit an empty grade
        try {
            system.openGradeEntryDialog(testUser);
            // Assuming the grade entry process throws an exception or displays a validation error message
            // Test passes if expected validation error messages are displayed or exceptions are thrown
        } catch (Exception e) {
            // Test passes if an exception is thrown during the grade entry process
            // You can also add assertions to verify the specific type of exception or error message
        }
    }
}
