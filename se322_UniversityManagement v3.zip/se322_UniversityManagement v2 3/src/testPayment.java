import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class testPayment {
    UniversityManagement system = new UniversityManagement();

    @Test
    public void testMakePayment_Positive() throws UniversityManagement.InsufficientPaymentException {
        system.makePayment(56000); // Attempt to make a payment with a positive integer amount
        assertTrue(system.isPaymentMade);
    }

    @Test
    public void testMakePayment_Negative() throws UniversityManagement.InsufficientPaymentException {
        try {
            system.makePayment(Double.parseDouble("InvalidAmount")); // Attempt to make a payment with a string amount
            assertFalse(system.isPaymentMade);
        }catch (Exception e){

        }
    }
}
