import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class testGetUserById {

    // Test case to verify that a non-existent user ID returns null
    @Test
    public void testGetUserById_NotFound() {
        UniversityManagement userManagement = new UniversityManagement();
        // Assert that the user with ID "nonexistentId" is not found and returns null
        assertNull(userManagement.getUserById("nonexistentId"));
    }

    // Test case to verify that an existing user can be found by ID
    @Test
    public void testGetUserById_Found() {
        UniversityManagement userManagement = new UniversityManagement();
        // Create a new user with ID "existingId", name "John Doe", and type STUDENT
        User user = new User("existingId", "John Doe", UserType.STUDENT);
        // Add the created user to the user management system
        userManagement.addUser(user.getId(), user.getPassword(), user.getType());

        // Assert that the user object is not null, indicating it was created
        assertNotNull(user);
        // Assert that the user ID matches the expected value
        assertEquals("existingId", user.getId());
        // Assert that the user password matches the expected value
        assertEquals("John Doe", user.getPassword());
    }
}

