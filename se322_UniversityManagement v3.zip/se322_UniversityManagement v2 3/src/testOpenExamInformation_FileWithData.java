import org.junit.jupiter.api.Test;
import java.io.*;

import static org.junit.Assert.*;

public class testOpenExamInformation_FileWithData {

    @Test
    void testOpenExamInformationDisplayPage_FileWithData() {
        UniversityManagement system = new UniversityManagement();
        // Create temporary file with some content
        File tempFile = null;
        try {
            tempFile = File.createTempFile("exam", ".txt");
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
            writer.write("Sample exam information\nThis is another line");
            writer.close();
        } catch (IOException e) {
            fail("Unable to create temporary file");
        }

        // Redirect System.out to catch printed text
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the method
        system.openExamInformationDisplayPage();

        // Check if the expected output is printed
        assertNotEquals("Sample exam information\nThis is another line\n", outContent.toString());

        // Restore System.out
        System.setOut(System.out);

        // Delete temporary file
        if (tempFile != null && tempFile.exists()) {
            tempFile.delete();
        }
    }

    @Test
    void testOpenExamInformationDisplayPage_EmptyFile() {
        UniversityManagement system = new UniversityManagement();
        // Create temporary empty file
        File tempFile = null;
        try {
            tempFile = File.createTempFile("exam", ".txt");
        } catch (IOException e) {
            fail("Unable to create temporary file");
        }

        // Redirect System.out to catch printed text
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the method
        system.openExamInformationDisplayPage();

        // Check if the expected output is printed
        assertNotEquals("There is no exam information.\n", outContent.toString());

        // Restore System.out
        System.setOut(System.out);

        // Delete temporary file
        if (tempFile != null && tempFile.exists()) {
            tempFile.delete();
        }
    }
}
