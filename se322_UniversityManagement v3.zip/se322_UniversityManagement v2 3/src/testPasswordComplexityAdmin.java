import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

public class testPasswordComplexityAdmin {
    UniversityManagement system = new UniversityManagement();
    @Test
    public void positivePasswordComplexityTestAdmin() {
        // Creating a new user: username "userWithComplexPassword", password "StrongPassword123!", and user type ADMIN
        User user = new User("userWithComplexPassword", "StrongPassword123!", UserType.ADMIN);
        // Adding this user to the system
        system.addUser(user.getId(), user.getPassword(), user.getType());
        // Attempting to login with the created user credentials
        User loggedInUser = system.login("userWithComplexPassword", "StrongPassword123!");
        // Checking if the user can successfully log in
        assertNotNull(loggedInUser, "Positive password complexity test failed for admin with complex password");
    }

    @Test
    public void negativePasswordComplexityTestAdmin() {
        // Creating a new user: username "userWithWeakPassword", password "weak123", and user type ADMIN
        User user = new User("userWithWeakPassword", "weak123", UserType.ADMIN);
        // Adding this user to the system
        system.addUser(user.getId(), user.getPassword(), user.getType());
        // Attempting to login with empty username and password
        User loggedInUser = system.login("", "");
        try {
            // Expecting the login to fail and checking for this condition
            assertNull(loggedInUser, "Negative password complexity test failed for admin with weak password");
        } catch (Exception e) {
            // Printing an error message in case of an exception
            System.out.println("ERROR!!!!!!");
        }
    }
}
