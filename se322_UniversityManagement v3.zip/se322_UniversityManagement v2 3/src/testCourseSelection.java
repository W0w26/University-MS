import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class testCourseSelection {
    UniversityManagement system = new UniversityManagement();
    // Positive Course Selection Test - Valid course selection
    @Test
    public void positiveCourseSelectionTest() {
        User user = new User("testUser", "password", UserType.STUDENT);
        system.addUser(user.getId(), user.getPassword(), user.getType()); // Add test user
        // Assuming the course selection dialog opens successfully without exceptions
        // Test passes if no exceptions are thrown
    }

    // Negative Course Selection Test - Invalid course selection
    @Test
    public void negativeCourseSelectionTest() {
        User user = new User("testUser", "password", UserType.STUDENT);
        system.addUser(user.getId(), user.getPassword(), user.getType()); // Add test user
        // Simulate course selection dialog with null frame
        Assertions.assertDoesNotThrow(() -> system.openCourseSelectionDialog(null, null),
                "Negative course selection test failed for null frame");
    }
}
